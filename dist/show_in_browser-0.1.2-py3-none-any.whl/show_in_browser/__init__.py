""" show_in_browser package
"""
__version__ = "0.1.2"

from .show_in_browser import show_df, show_plt_plot, show_px_plot
