""" show_in_browser package
"""

from .show_in_browser import show_df, show_plt_plot, show_px_plot
