""" df_in_browser package
"""

from .df_in_browser import show_df
