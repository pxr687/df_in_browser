A function to display a pandas dataframe in the browswer, to be run from the
command line, for better visualisation than viewing within the terminal.